import streamlit as st


def show_homepage():

    # Hero Title
    st.title("🚦 Chicago Traffic Crash Analytics Dashboard")

    # Subtitle
    st.subheader("Analyzing traffic crash patterns, injury trends, weather impacts, and high-risk zones in Chicago.")
    st.image("""/Users/shres/OneDrive/New folder/OneDrive/Desktop/guvipic.png""", width=700)

  
    # Project Overview
    st.markdown("## 📌 Project Overview")

    st.write("""
    This dashboard provides an analytical view of traffic crashes reported in the City of Chicago.

    The project uses SQL, Python, Pandas, and Streamlit to identify patterns related to:

    - Crash severity
    - Injury trends
    - Weather conditions
    - High-risk streets
    - Time-based crash analysis
    - Geographic crash hotspots
    """)

    # Dataset Information
    st.markdown("## 📂 Dataset Information")

    st.table({
        "Property": [
            "Dataset Name",
            "Source",
            "Format",
            "Total Records",
            "Time Range",
            "Spatial Coverage",
            "License",
            "SQL Table Name"
        ],
        "Details": [
            "Chicago Traffic Crashes",
            "Chicago Data Portal — data.cityofchicago.org",
            "CSV",
            "600,000+ rows",
            "2015 to Present",
            "Chicago, Illinois, USA",
            "Public Domain",
            "CrashTable"
        ]
    })

    # Features Section
    st.markdown("## 📊 Dashboard Features")

    col1, col2 = st.columns(2)

    with col1:
        st.info("""
        ✔ Weather vs Crash Analysis  
        ✔ Injury Severity Insights  
        ✔ Night-Time Crash Analysis  
        ✔ High-Risk Streets  
        """)

    with col2:
        st.info("""
        ✔ Interactive Maps  
        ✔ Crash Trend Analysis  
        ✔ Hourly Risk Detection  
        ✔ Crash Cause Analysis  
        """)

    # Footer
    st.markdown("---")

    st.caption(
        "Built using Streamlit, SQLAlchemy, Pandas, Plotly, and SQLite."
    )