import streamlit as st
import pandas as pd
from sqlalchemy import create_engine
from homepage import show_homepage
import matplotlib.pyplot as plt


option = st.sidebar.selectbox(
    "Select Page",
    ["Home", "Questions"]
)
if option =='Home':
    show_homepage()



#query = "SELECT * FROM traffic_crashes"


#df = pd.read_sql(query, con=app)


#st.dataframe(df.head(100))


elif option =='Questions':
    engine = create_engine("sqlite:///traffic_crashes.db")



    r = st.selectbox("Select an option", [
                                      "1.Top 5 Weather Conditions and Crash Types",
                                      "2.Identify the top 10 streets with the highest number of injury crashes",
                                      "3.Find the percentage of crashes that resulted in injuries for each crash type",
                                      '4.Determine the peak crash hour for each month',
                                      '5.Find the top 5 primary causes of crashes during night time hours (after 6 PM)',
                                      '6.Compare average number of injuries in daylight vs darkness conditions. ',
                                      '7.Find which traffic control device type has the highest average injuries per crash.',
                                      '8.Identify the top 5 locations (latitude/longitude) with the highest crash frequency. ',
                                      '9.Find the top 5 streets with the highest injury rate, considering only streets with more than 100 crashes. ',
                                      '10.For each year, identify the most common crash type. ',
                                      '11.Find the day of the week with the highest average crashes per hour. ',
                                      '12.high-risk time slots',
                                      '13.Top 3 contributing causes for each crash type',
                                      '14.Year-over-Year Growth Rate of Crashes',
                                      '15.Identify Hotspot Zones'
                                      ])
    

    if r == "1.Top 5 Weather Conditions and Crash Types":
        query2 = 'select weather_condition, crash_type, count(*) as total_crashes from traffic_crashes group by weather_condition, crash_type order by total_crashes desc limit 5;'
        df2=pd.read_sql(query2,con=engine)


        df2["combination"] = (
                df2["WEATHER_CONDITION"] + " | " + df2["CRASH_TYPE"]
            )

        fig, ax = plt.subplots(figsize=(10,5))

        ax.barh(df2["combination"], df2["total_crashes"])

        ax.set_xlabel("Total Crashes")
        ax.set_title("Top 5 Weather & Crash Type Combinations")

        st.pyplot(fig)
        
        st.table(df2)
    
    ###2
    if r == "2.Identify the top 10 streets with the highest number of injury crashes":
        query3 = 'select street_name,count(*) as total_crashes from traffic_crashes where injuries_total>0 group by street_name order by total_crashes desc limit 10;'
        df3=pd.read_sql(query3,con=engine)
        st.table(df3)
        
    
    if r == "3.Find the percentage of crashes that resulted in injuries for each crash type":
        query4 = "select crash_type, round(100.0 * sum(case when injuries_total > 0 then 1 else 0 end) / count(*), 2) as percentage from traffic_crashes group by crash_type order by percentage desc;"
        df4 = pd.read_sql(query4, con=engine)
        st.dataframe(df4)
    
    
    if r=='4.Determine the peak crash hour for each month':
        query5 = " select crash_month , crash_hour,max(total_crashes) as peak_crash_hour from(select crash_month, crash_hour, count(*) as total_crashes from traffic_crashes group by crash_month, crash_hour order by crash_month desc) group by crash_month order by crash_month;"
        df5 = pd.read_sql(query5, con=engine)
        st.table(df5)
    
    
    if r=='5.Find the top 5 primary causes of crashes during night time hours (after 6 PM)':
        query6 = "select prim_contributory_cause,crash_hour, count(*) as total_crashes   from traffic_crashes where crash_hour >18  group by prim_contributory_cause order by total_crashes desc limit 5;"
        df6 = pd.read_sql(query6, con=engine)  
        st.dataframe(df6)
    
    if r=='6.Compare average number of injuries in daylight vs darkness conditions. ':
        query7 = "select lighting_condition,avg(injuries_total) as total_injuries from traffic_crashes where lighting_condition='DAYLIGHT' or lighting_condition like 'DARKNESS%' group by lighting_condition;"
        df7 = pd.read_sql(query7, con=engine)
        st.dataframe(df7)                   
        
    
    if r=='7.Find which traffic control device type has the highest average injuries per crash.':
        query8 ="select traffic_control_device,avg(injuries_total) as avg_total_injuries from traffic_crashes group by traffic_control_device order by avg_total_injuries desc;"
        df8=pd.read_sql(query8,con=engine)
        st.table(df8)
        


    if r=='8.Identify the top 5 locations (latitude/longitude) with the highest crash frequency. ':
        query9 = "select street_name,longitude,latitude,location,count(injuries_total) as total_injuries from traffic_crashes group by location order by total_injuries desc limit 5;"
        df9 = pd.read_sql(query9, con=engine)
        st.table(df9)
        map_data = df9[['LATITUDE', 'LONGITUDE']]
        st.map(map_data)


    
    
    if r=='9.Find the top 5 streets with the highest injury rate, considering only streets with more than 100 crashes. ':
        query9 = "select street_name, 100*sum(injuries_total) * 1.0 / count(*) as injury_rate, count(*) as total_crashes from traffic_crashes group by street_name having count(*) > 100 order by injury_rate desc limit 5;"
        df9 = pd.read_sql(query9, con=engine)
        st.dataframe(df9)


        
    
    if r=='10.For each year, identify the most common crash type. ':
        query10 ='select year,crash_type,count(*) as total_crashes from traffic_crashes group by year, crash_type having count(*) =(select max(crash_count) from ( select count(*) as crash_count from traffic_crashes t2 where t2.year = traffic_crashes.year group by crash_type )) order by year,total_crashes desc;' 
        df10=pd.read_sql(query10, con=engine)
        st.dataframe(df10) 
        
    
    
    if r =='11.Find the day of the week with the highest average crashes per hour. ':
        query11='select crash_day_of_week, avg(total_crashes) as avg_crashes from (select crash_day_of_week,crash_hour,count(*) as total_crashes from traffic_crashes group by crash_day_of_week,crash_hour) group by crash_day_of_week order by avg(total_crashes) desc limit 1;' 
        df11 = pd.read_sql(query11, con=engine)
        st.table(df11)
        


        
    if r=='12.high-risk time slots':
        query12='''select case when crash_hour between 6 and 11 then 'morning' when crash_hour between 12 and 17 then 'afternoon' when crash_hour between 18 and 21 then 'evening' else 'night' end as time_of_day,sum(injuries_total) as total_injuries from traffic_crashes group by time_of_day order by total_injuries desc limit 4;'''
        df12 = pd.read_sql(query12, con=engine)
        st.table(df12)


            
    if r=='13.Top 3 contributing causes for each crash type':
        query13 = '''
        select crash_type, prim_contributory_cause, total_crashes
        from (
            select crash_type,
                prim_contributory_cause,
                count(*) as total_crashes,
                row_number() over (
                    partition by crash_type
                    order by count(*) desc
                ) as rn
            from traffic_crashes
            group by crash_type, prim_contributory_cause
        )
        where rn <= 3;
        '''
        df13 = pd.read_sql(query13, con=engine)
        st.table(df13)



        
    if r=='14.Year-over-Year Growth Rate of Crashes':
        query14 = '''
        select year,
            total_crashes,
            round(
                100.0 * (
                    total_crashes -
                    lag(total_crashes) over(order by year)
                ) /
                lag(total_crashes) over(order by year),
                2
            ) as growth_rate
        from (
            select year,
                count(*) as total_crashes
            from traffic_crashes
            group by year
        );
        '''
        df14 = pd.read_sql(query14, con=engine)
        st.table(df14)

    if r=='15.Identify Hotspot Zones':
        query15 = '''
        select round(latitude,2) as lat_zone,
            round(longitude,2) as lon_zone,
            count(*) as total_crashes
        from traffic_crashes
        where latitude is not null
        and longitude is not null
        group by lat_zone, lon_zone
        order by total_crashes desc
        limit 10;
        '''

        df15 = pd.read_sql(query15, con=engine)

        st.table(df15)

        map_data = df15[['lat_zone', 'lon_zone']]
        map_data.columns = ['latitude', 'longitude']

        st.map(map_data)