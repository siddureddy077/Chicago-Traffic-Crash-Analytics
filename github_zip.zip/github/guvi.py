import pandas as pd
from sqlalchemy import create_engine

# Read CSV
df = pd.read_csv("Traffic_CrashesData.csv")

# Create database connection
engine = create_engine("sqlite:///traffic_crashes.db")

# Store data into SQL table
df.to_sql(
    "traffic_crashes",
    con=engine,
    if_exists="replace",
    index=False
)

print("Data loaded successfully!")